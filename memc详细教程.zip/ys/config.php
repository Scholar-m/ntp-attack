<?php
ini_set("memory_limit", "512M");
set_time_limit(0);
ignore_user_abort(FALSE);
error_reporting(E_ALL);
define("TEST_TIMEOUT", 2);
define("QUERY_LENGTH", 100);
define("STAT_QUERY_LENGTH", 20);

if(!is_callable("random_bytes")){
	include __DIR__."/paragonie_random_compact/lib/random.php";
}